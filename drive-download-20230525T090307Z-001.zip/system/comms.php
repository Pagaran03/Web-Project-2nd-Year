<?php

session_start();

include 'config.php';


// Check if the form has been submitted
if(isset($_POST['submit'])) {
    // Get the comment data from the form
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);

    // Insert the comment into the database with a status of "pending"
    $sql = "INSERT INTO comms(comment, full_name, status)
            VALUES ('$comment', '$username', 'pending')";
    mysqli_query($conn, $sql);
}

// Check if the admin has approved a comment
if(isset($_GET['approve'])) {
    // Get the ID of the comment to approve
    $id = mysqli_real_escape_string($conn, $_GET['approve']);

    // Update the comment's status to "approved"
    $sql = "UPDATE comment SET status='approved' WHERE id=$id";
    mysqli_query($conn, $sql);
}

// Get all approved comments from the database
$sql = "SELECT * FROM comment WHERE status='approved'";
$result = mysqli_query($conn, $sql);

// Display the comments
while($row = mysqli_fetch_assoc($result)) {
    echo "<p>" . $row['username'] . " said: " . $row['comment'] . "</p>";
}
