<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
}

include 'config.php';

if (isset($_POST["submit"])) {
    if (empty($_POST["content_post"]) && empty($_FILES["file"]["name"])) {
        echo "<script>alert('Please enter a sentence or upload a file.');</script>";
    } elseif (empty($_POST["content_post"]) && !empty($_FILES["file"]["name"])) {
        $allowed_file_types = array('jpg', 'jpeg', 'png', 'gif', 'pdf', 'txt', 'mp4', 'mkv', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'zip', 'rar');
        $file_name = mysqli_real_escape_string($conn, $_FILES["file"]["name"]);
        $file_tmp_name = $_FILES["file"]["tmp_name"];
        $file_size = $_FILES["file"]["size"];
        $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        // Check if the user is an admin
        if ($_SESSION['user_type'] != 'admin') {
            echo "<script>alert('Only admin have permission to submit a file.');</script>";
        } else if ($file_size > 25000000) {
            echo "<script>alert('File is too big. Maximum file size is 25MB.');</script>";
        } else if (!in_array($file_type, $allowed_file_types)) {
            echo "<script>alert('Invalid file type. Please upload a valid file type.');</script>";
        } else {
            // check if file type is jpg, jpeg, png, gif
            if (in_array($file_type, array('jpg', 'jpeg', 'png', 'gif'))) {
                $table_name = "photos";
            } else if (in_array($file_type, array('mp4', 'mkv'))) {
                $table_name = "videos";
            } else {
                $table_name = "tableall";
            }

            $sql = "SELECT * FROM users WHERE id='{$_SESSION["user_id"]}'";
            $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $fullname = $row['full_name'];
                }
            }

            // Generate new file name
            $file_new_name = rand() . $file_name;

            // Prepare query for inserting into the database
            $sql = "INSERT INTO $table_name (file_name, file_type, file_path, user_id, full_name) VALUES ('$file_new_name', '$file_type', 'attachments/$file_new_name', '{$_SESSION["user_id"]}', '$fullname')";

            // Execute query and move the uploaded file
            if (mysqli_query($conn, $sql) && move_uploaded_file($file_tmp_name, "attachments/" . $file_new_name)) {
                header("Location: welcome.php");
            } else {
                echo "<script>alert('File Cannot Be Uploaded.');</script>";
            }
        }
    } elseif (empty($_FILES["file"]["name"]) && !empty($_POST["content_post"])) {
        if ($_SESSION['user_type'] != 'admin') {
            echo "<script>alert('Only admin have permission to submit a file.');</script>";
        } else {

            $sql = "SELECT * FROM users WHERE id='{$_SESSION["user_id"]}'";
            $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $fullname = $row['full_name'];
                }
            }

            $sentence = mysqli_real_escape_string($conn, $_POST['content_post']);
            // Insert sentence into tblposts table
            $sql = "INSERT INTO posts (content, user_id, full_name) VALUES ('$sentence', '{$_SESSION["user_id"]}', '$fullname')";
            if (mysqli_query($conn, $sql)) {
                header("Location: welcome.php");
            } else {
                echo "<script>alert('Sentence cannot be posted.');</script>";
            }
        }
    } else {
        $allowed_file_types = array('jpg', 'jpeg', 'png', 'gif', 'pdf', 'txt', 'mp4', 'mkv', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'zip', 'rar');
        $file_name = mysqli_real_escape_string($conn, $_FILES["file"]["name"]);
        $file_tmp_name = $_FILES["file"]["tmp_name"];
        $file_size = $_FILES["file"]["size"];
        $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if ($_SESSION['user_type'] != 'admin') {
            echo "<script>alert('You do not have permission to submit a file.');</script>";
        } else if ($file_size > 25000000) {
            echo "<script>alert('File is too big. Maximum file size is 25MB.');</script>";
        } else if (!in_array($file_type, $allowed_file_types)) {
            echo "<script>alert('Invalid file type. Please upload a valid file type.');</script>";
        } else {

            $sql = "SELECT * FROM users WHERE id='{$_SESSION["user_id"]}'";
            $result = mysqli_query($conn, $sql);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $fullname = $row['full_name'];
                }
            }

            $file_new_name = rand() . $file_name;
            $sentence = mysqli_real_escape_string($conn, $_POST['content_post']);
            $sql = "INSERT INTO tableall (file_name, file_type, file_path, content, user_id, full_name) VALUES ('$file_new_name', '$file_type', 'attachments/$file_new_name', '$sentence', '{$_SESSION["user_id"]}', '$fullname')";
            if (mysqli_query($conn, $sql) && move_uploaded_file($file_tmp_name, "attachments/" . $file_new_name)) {
                header("Location: welcome.php");
            } else {
                echo "<script>alert('File Cannot Be Uploaded.');</script>";
            }
            if (isset($_POST["submit_comment"])) {
                $comment = mysqli_real_escape_string($conn, $_POST['comment_content']);
                $post_id = mysqli_real_escape_string($conn, $_POST['post_id']);
                $user_id = $_SESSION["user_id"];

                if (!isset($post_id) || !isset($full_name)) {
                    echo "<script>alert('Please fill in all required fields.');</script>";
                } else {
                    $sql = "INSERT INTO comment (comment_content, post_id, user_id) VALUES ('$comment', '$post_id', '$user_id')";
                    if (mysqli_query($conn, $sql)) {
                        header("Location: welcome.php");
                    } else {
                        echo "<script>alert('Comment submission failed.');</script>";
                    }
                }
            }

            

        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/main/main-style.css">
    <title>Dhar Mann's Event - Home</title>
</head>

<body>

    <form action="" method="post" enctype="multipart/form-data">
        <?php
        $sql = "SELECT * FROM users WHERE id='{$_SESSION["user_id"]}'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
        ?>
                <div class="home">
                    <div class="container">
                        <div class="home-weapper">
                            <div class="home-left">

                                <div class="profile">
                                    <img src="img/profile.jfif" alt="user">
                                    <h3>
                                        <?php echo $row['user_type']; ?>
                                    </h3>
                                </div>

                                <div class="header-container">
                                    <div class="header-wrapper">
                                        <h5>LOGIN ACCOUNT
                                            <hr>
                                            <a id="name"><?php echo $row['full_name']; ?></a>

                                        </h5>
                                    </div>
                                </div>

                                <hr>
                                <div id="popupTable" class="popup">
                                    <div class='userslst'>
                                        <?php
                                        $sql = "SELECT * FROM users";
                                        $result = mysqli_query($conn, $sql);
                                        if (mysqli_num_rows($result) > 0) {
                                            if ($row["user_type"] == "admin") {
                                                echo "<h3>Userlist</h3> ";
                                            }
                                        }

                                        ?>
                                        <?php
                                        $sql = "SELECT * FROM users";
                                        $result = mysqli_query($conn, $sql);
                                        if (mysqli_num_rows($result) > 0) {
                                            if ($row["user_type"] == "admin") {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    $full_name = $row['full_name'];
                                                    echo "    
                                                <div class='users'>
                                                   <i><img src='img/male-avatar.svg' alt='' class='avatar'></i>
                                                    <a>$full_name</a>
                                                   </div>";
                                                }
                                            }
                                        }

                                        ?>

                                    </div>
                                </div><br>

                                <hr>


                                <div class="event">
                                    <h3 class="heading">Donations</h3>

                                    <div class="event-date">
                                        <h4 id="gcash">GCASH <span># 09477872803</span></h4>
                                    </div>

                                    <input type="number" placeholder="Amount" name="donation_input" value="" /><br>
                                    <button id="open-donation-btn" name="donate-btn"><i class="fas fa-donate"></i> Donate</button>
                                </div>


                            </div>

                            <div class="home-center">
                                <div class="home-center-wrapper">
                                    <div class="createPost">
                                        <h3 class="mini-headign">Post Material</h3>
                                        <form action="" method="post" enctype="multipart/form-data">
                                            <div class="post-text">
                                                <input type="text" placeholder="Type here" name="content_post" value="" />
                                            </div>
                                            <div class="post-icon">
                                                <form action="" method="post" enctype="multipart/form-data">

                                                    <label for="file-input" style="cursor: pointer;">
                                                        <i class="fa-solid fa-file"></i>
                                                        <input type="file" id="file-input" name="file" style="display:none;">
                                                        Select a File
                                                    </label>
                                                    <label style="cursor: pointer; ">
                                                        <i class="fa fa-upload"></i>
                                                        <input type="submit" name="submit" value="Upload" style="display:none;">
                                                        Post
                                                    </label>
                                                    </a>
                                                </form>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <?php
                                $counter = 1;
                                $sql = "SELECT * FROM posts";
                                $result = mysqli_query($conn, $sql);
                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $content = $row['content'];
                                        $user_id = $row['user_id'];
                                        $full_name = $row['full_name'];

                                        echo "<div class='fb-post" . $counter . "'>
                                             <div class='fb-post-container'>
                                                 <div class='fb-p-main'>
                                                 <div class='post-title'>
                                                 <ul>
                                                     <li>
                                                         <h3>$full_name</h3>
                                                     </li>
                                                 </ul>
                                                 <p>$content
                                             </p>
                                             </div>
                                                 </div>
                                             </div>
                                             <br>
                                             <br>
                                             <br>
                                             <br>
                                             <hr>
                                             <div class='fb-post-comments'>
                                               <form action='' method='post'>
	                                            <textarea name='comment' placeholder='Comment here'></textarea><br>
	                                            <input id='open-submit-btn' type='submit' name='submit_comment' value='Submit Comment'>
                                               </form>
                                               
                                               
                                             </div>

                                         </div>";
                                        $counter++;
                                    }
                                }
                                $counter = 1;
                                $sql = "SELECT * FROM photos";
                                $result = mysqli_query($conn, $sql);
                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $file_url = $row['file_path'];
                                        $file_name = $row['file_name'];
                                        $file_type = $row['file_type'];
                                        if ($file_type == 'jpg' || $file_type == 'jpeg' || $file_type == 'png' || $file_type == 'gif') {
                                            echo "<div class='fb-post" . $counter . "'>
                                            <div class='fb-post-container'>
                                                <div class='fb-p-main'>
                                                <div class='post-title'>
                                                <ul>
                                                    <li>
                                                        <h3>$full_name</h3>
                                                    </li>
                                                    <li><span></span></li>
                                                </ul>
                                                <p>dd;
                                            </p>
                                            </div>
                                                <img src='$file_url' alt='Uploaded Image' style='width: 100%;' >
                                                </div>
                                            </div>
                                        </div>";
                                            $counter++;
                                        }
                                    }
                                }
                                $sql = "SELECT * FROM videos";
                                $result = mysqli_query($conn, $sql);
                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $file_url = $row['file_path'];
                                        $file_name = $row['file_name'];
                                        $file_type = $row['file_type'];
                                        $fullname = $row['full_name'];
                                        if ($file_type == 'mp4' || $file_type == 'mkv') {
                                            echo "<div class='fb-post" . $counter . "'>
                                            <div class='fb-post-container'>
                                                <div class='fb-p-main'>
                                                <div class='post-title'>
                                                <ul>
                                                    <li>
                                                        <h3>$fullname</h3>
                                                    </li>
                                                    <li><span>02 march at 12:55 PM</span></li>
                                                </ul>
                                                <p>Hello Everyone Thanks for Watching Please SUBSCRIBE My Channel - Like
                                                Comments and Share
                                            </p>
                                            </div>
                                                <video width='852' height='320' controls>
                                                <source src='$file_url' type='video/mp4'>
                                                </video>
                                                </div>
                                            </div>
                                        </div>";
                                            $counter++;
                                        }
                                    }
                                }
                                $sql = "SELECT * FROM tableall";
                                $result = mysqli_query($conn, $sql);
                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $file_url = $row['file_path'];
                                        $file_name = $row['file_name'];
                                        $file_type = $row['file_type'];
                                        $fullname = $row['full_name'];
                                        $content = $row['content'];
                                        if ($file_type == 'mp4' || $file_type == 'mkv') {
                                            echo "<div class='fb-post" . $counter . "'>
                                            <div class='fb-post-container'>
                                                <div class='fb-p-main'>
                                                <div class='post-title'>
                                                <ul>
                                                    <li>
                                                        <h3>$fullname</h3>
                                                    </li>
                                                </ul>
                                                <p>$content
                                            </p>
                                            </div>
                                                <video width='852' height='320' controls>
                                                <source src='$file_url' type='video/mp4'>
                                                </video>
                                                </div>
                                            </div>
                                        </div>";
                                            $counter++;
                                        }
                                    }
                                }
                                $sql = "SELECT * FROM tableall";
                                $result = mysqli_query($conn, $sql);
                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $file_url = $row['file_path'];
                                        $file_name = $row['file_name'];
                                        $file_type = $row['file_type'];
                                        $fullname = $row['full_name'];
                                        $content = $row['content'];
                                        if ($file_type == 'jpg' || $file_type == 'jpeg' || $file_type == 'png' || $file_type == 'gif') {
                                            echo "<div class='fb-post" . $counter . "'>
                                            <div class='fb-post-container'>
                                                <div class='fb-p-main'>
                                                <div class='post-title'>
                                                <ul>
                                                    <li>
                                                        <h3>$fullname</h3>
                                                    </li>
                                                </ul>
                                                <p>$content
                                            </p>
                                            </div>
                                                <img src='$file_url' alt='Uploaded Image' style='width: 100%;'>
                                                </div>
                                            </div>
                                        </div>";
                                            $counter++;
                                        }
                                    }
                                }

                                ?>

                            </div>
                            <div class="home-right">
                                <div class="home-right-wrapper">


                                    <div class="event-friend">
                                        <div class="event">

                                            <div class="header-container">
                                                <div class="header-wrapper">
                                                    <p>Want to logout?
                                                        <a id="click" href="logout.php">Click Here</a>

                                                    </p>
                                                </div>
                                            </div>


                                            <h3 class="heading">List of Donators</h3>
                                            <table id="donate">
                                                <tr>

                                                    <th>Name</th>
                                                    <th>Amount</th>

                                                </tr>
                                                <hr>
                                                <?php
                                                $sql = "SELECT * FROM donate";
                                                $result = mysqli_query($conn, $sql);
                                                if (mysqli_num_rows($result) > 0) {
                                                    while ($row = mysqli_fetch_assoc($result)) {
                                                        $Name = $row['full_name'];
                                                        $Donations = $row['donation'];

                                                        echo "<tr>
                                                  <th>$Name</th>
                                                  <th>$Donations</th>
                                                </tr>";
                                                    }
                                                }
                                                ?>
                                            </table><br>







                                        </div>
                                    </div>


                            <?php

                        }
                    }
                            ?>
                                </div>
                                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                                <script>
                                    document.getElementById("file-input").addEventListener("click", function() {
                                        document.getElementById("file-input").click();
                                    });
                                    var darkButton = document.querySelector(".darkTheme");

                                    darkButton.onclick = function() {
                                        darkButton.classList.toggle("button-Active");
                                        document.body.classList.toggle("dark-color")
                                    }
                                </script>
                                <script>
                                    document.getElementById("open-donation-btn").addEventListener("click", function(event) {
                                        event.preventDefault();
                                        const donationInput = document.getElementsByName("donation_input")[0].value;
                                        if (!donationInput || donationInput == 0) {
                                            alert("Fdailed to Donate");
                                        } else {
                                            alert("Successfully Donated");
                                            window.location.replace("index.php");
                                            fetch('donation.php', {
                                                    method: 'POST',
                                                    headers: {
                                                        'Content-Type': 'application/x-www-form-urlencoded'
                                                    },
                                                    body: `donation_input=${donationInput}`
                                                })
                                                .then(response => response.text())
                                                .then(data => {})
                                                .catch(error => {});
                                        }
                                    });
                                </script>
                                <script>
                                    document.getElementById("opsn-submit-btn").addEventListener("click", function(event) {
                                        event.preventDefault();
                                        const commentInput = document.getElementsByName("submit_comment")[0].value;
                                        if (!commentInput || commentInput == 0) {
                                            alert("Fdailed ");
                                        } else {
                                            alert("Successfully ");
                                            window.location.replace("index.php");
                                            fetch('comms.php', {
                                                    method: 'POST',
                                                    headers: {
                                                        'Content-Type': 'application/x-www-form-urlencoded'
                                                    },
                                                    body: `submit_comment=${commentInput}`
                                                })
                                                .then(response => response.text())
                                                .then(data => {})
                                                .catch(error => {});
                                        }
                                    });
                                </script>

</body>

</html>