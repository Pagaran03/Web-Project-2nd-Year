<?php
session_start();
include('config.php');

if(isset($_POST['signin']))
{
    
        $email = mysqli_real_escape_string($conn, $_POST["email"]);
        $password = mysqli_real_escape_string($conn, md5($_POST["password"]));

        $login_query = "SELECT * FROM users WHERE email='$email' AND password='$password' LIMIT 1";
        $login_query_run = mysqli_query($conn, $login_query);

        if(mysqli_num_rows($login_query_run) > 0)
        {
            $row = mysqli_fetch_array($login_query_run);
            if($row['verify_status']=="1")
            {
                if ($row["user_type"] == "admin") {
                    $_SESSION["user_id"] = $row['id'];
                    $_SESSION["user_type"] = $row['user_type'];
                    $_SESSIOM["full_name"] = $row['full_name'];
                    header("Location: welcome.php");
                  } else {
                    $_SESSION["user_id"] = $row['id'];
                    $_SESSION["user_type"] = $row['user_type'];
                    $_SESSIOM["full_name"] = $row['full_name'];
                    header("Location: welcome.php");
                  }
            }
            else
            {
                $_SESSION['status'] = "Verify your Email first";
                header("Location: index.php");
                exit(0);
    
            }
        }
        else
        {
            $_SESSION['status'] = "invalid email or password";
            header("Location: index.php");
            exit(0);
        }

}
