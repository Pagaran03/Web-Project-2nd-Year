<?php

include 'config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

session_start();

error_reporting(0);

if (isset($_SESSION["user_id"])) {
  header("Location: welcome.php");
}

$total_users = 50;
$result = mysqli_query($conn, "SELECT COUNT(*) as id FROM users WHERE user_type='user'");
$data = mysqli_fetch_assoc($result);
$current_count = $data['id'];

if (isset($_POST["signup"])) {

  $full_name = mysqli_real_escape_string($conn, $_POST["signup_full_name"]);
  $email = mysqli_real_escape_string($conn, $_POST["signup_email"]);
  $password = mysqli_real_escape_string($conn, md5($_POST["signup_password"]));
  $cpassword = mysqli_real_escape_string($conn, md5($_POST["signup_cpassword"]));
  $birthday = mysqli_real_escape_string($conn, $_POST["signup_birthday"]);
  $token = md5(rand());

  $check_email = mysqli_num_rows(mysqli_query($conn, "SELECT email FROM users WHERE email='$email'"));


  if ($password !== $cpassword) {
    echo "<script>alert('Password did not match.');</script>";
  } elseif ($check_email > 0) {
    echo "<script>alert('Email already exists.');</script>";
  } else {
    $age = (date("Y") - date("Y", strtotime($birthday)));
    if ($age < 18) {
      echo "<script>alert('You are not eligible to register, As you are below 18');</script>";
    } elseif ($age > 30) {
      echo "<script>alert('You are not eligible to register, As you are above 30');</script>";
    } else {
      if ($current_count >= $total_users) {
        echo "<script>alert('Sorry, the maximum number of registered users has been reached.');</script>";
      } else {
        $sql = "INSERT INTO users (full_name, email, password, token, birthday, user_type) VALUES ('$full_name', '$email', '$password', '$token', '$birthday', 'user')";
        if (mysqli_query($conn, $sql)) {
          echo "<script>alert('Register Successfully.');</script>";
          // Send verification email
          $mail = new PHPMailer(true);
          try {

            $mail->isSMTP();                                            // Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = 'sherdypagaran9@gmail.com';                   // SMTP username
            $mail->Password   = 'fuiyuszsbdcmhcsb';                             // SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; PHPMailer::ENCRYPTION_SMTPS encouraged
            $mail->Port       = 25;                                    // TCP port to connect to, use 465 for PHPMailer::ENCRYPTION_SMTPS above

            $mail->setFrom('sherdypagaran9@gmail.com', 'Sherdy Pagaran');
            $mail->addAddress($email);     // Add a recipient
            $mail->addReplyTo('no-reply@example.com', 'No Reply');

            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = 'Email Verification';
            $mail->Body    = 'Click the link to verify your account: <a href="http://localhost/SIA/verify.php?token=' . $token . '">Verify</a>';

            $mail->send();
            echo "<script>alert('Verification email sent');</script>";
          } catch (Exception $e) {
            echo "<script>alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}');</script>";
          }
          header("refresh: 1");
        } else {
          echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
      }
    }
  }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="css/style.css" />

  <title>EVENT</title>
</head>

<body>
  <div class="container">
    <div class="forms-container">
      <div class="signin-signup">
        <?php
        if (isset($_SESSION['status']) && !empty($_SESSION['status'])) {
        ?>
          <script type="text/javascript">
            alert("<?= $_SESSION['status']; ?>");
          </script>
        <?php
          unset($_SESSION['status']);
        }
        ?>
        <form action="login.php" method="post" class="sign-in-form">
          <h2 class="title">Login</h2>
          <div class="input-field">
            <i class="fas fa-users"></i>
            <input type="text" placeholder="Email Address" name="email" value="<?php echo $_POST['email']; ?>" required />
          </div>
          <div class="input-field">
            <i class="fas fa-lock"></i>
            <input type="password" placeholder="Password" name="password" value="<?php echo $_POST['password']; ?>" required />
          </div>
          <input type="submit" value="Login" name="signin" class="btn solid" />
          <p style="display: flex;justify-content: center;align-items: center;margin-top: 20px;"><a href="forgot-password.php" style="color: #4590ef;">Forgot Password?</a></p>
        </form>
        <form action="" class="sign-up-form" method="post">
          <h2 class="title">Register</h2>
          <div class="input-field">
            <i class="fas fa-user"></i>
            <input type="text" placeholder="Full Name" name="signup_full_name" value="<?php echo $_POST["signup_full_name"]; ?>" required />
          </div>
          <div class="input-field">
            <i class="fas fa-envelope"></i>
            <input type="email" placeholder="Email Address" name="signup_email" value="<?php echo $_POST["signup_email"]; ?>" required />

          </div>



          <div class="input-field">
            <i class="fas fa-lock"></i>
            <input type="password" placeholder="Password" name="signup_password" value="<?php echo $_POST["signup_password"]; ?>" required />
          </div>
          <div class="input-field">
            <i class="fas fa-lock"></i>
            <input type="password" placeholder="Confirm Password" name="signup_cpassword" value="<?php echo $_POST["signup_cpassword"]; ?>" required />
          </div>
          <div class="input-field">
            <i class="fas fa-birthday-cake"></i>
            <input type="date" placeholder="Birthday (MM/DD/YY)" name="signup_birthday" value="<?php echo $_POST["signup_birthday"]; ?>" required />
          </div>
          <input type="submit" class="btn" name="signup" value="Sign up" />
        </form>
      </div>
    </div>

    <div class="panels-container">

      <div class="panel right-panel">
        <div class="content">
          <h3>Already Registered ?</h3>
          <p>
            Log in right away to see the event featuring Dhar Mann

          </p>
          <button class="btn transparent" id="sign-in-btn">
            Login
          </button>
        </div>

        <img src="img/LOGIN.svg" class="image" alt="" />
      </div>
      <div class="panel left-panel">
        <div class="content">
          <h3>Dont have an account ?</h3>
          <p>
            Register now to see the event featuring Dhar Mann!
          </p>
          <p>
            Number of Participants:
            <?php echo $current_count; ?> /
            <?php echo $total_users; ?>
          </p>
          <button class="btn transparent" id="sign-up-btn">
            Register
          </button>
        </div>

        <img src="img/Registration.svg" class="image" alt="" />
      </div>
    </div>
  </div>

  <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
  <script src="app.js"></script>

</body>

</html>